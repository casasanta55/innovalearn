import Navbar from "../components/Navbar";

export default function Home() {
  return (
    <div>
      <Navbar />
      <h1>Bienvenido a InnovaLearn</h1>
      <p>Explora cursos, productos y suscripciones.</p>
    </div>
  );
}