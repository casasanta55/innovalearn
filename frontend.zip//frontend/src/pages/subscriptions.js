import { useEffect, useState } from "react";
import { getSubscriptions } from "../utils/api";
import SubscriptionCard from "../components/SubscriptionCard";

export default function Subscriptions() {
  const [subs, setSubs] = useState([]);

  useEffect(() => {
    const fetchSubs = async () => {
      const data = await getSubscriptions();
      setSubs(data);
    };
    fetchSubs();
  }, []);

  return (
    <div>
      <h2>Suscripciones</h2>
      {subs.map((sub) => (
        <SubscriptionCard key={sub._id} subscription={sub} />
      ))}
    </div>
  );
}