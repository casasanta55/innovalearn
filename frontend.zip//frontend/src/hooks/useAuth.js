import { useState, useEffect, useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import { login, register } from "../utils/api";

export default function useAuth() {
  const { user, setUser } = useContext(AuthContext);
  const [loading, setLoading] = useState(false);

  const handleLogin = async (email, password) => {
    setLoading(true);
    try {
      const res = await login(email, password);
      setUser({ token: res.token, email });
    } catch (err) {
      console.error("Error en login:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (name, email, password) => {
    setLoading(true);
    try {
      const res = await register(name, email, password);
      setUser({ token: res.token, email });
    } catch (err) {
      console.error("Error en registro:", err);
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
  };

  useEffect(() => {
    // Aquí podrías cargar usuario desde localStorage si quieres persistencia
  }, []);

  return { user, loading, handleLogin, handleRegister, logout };
}