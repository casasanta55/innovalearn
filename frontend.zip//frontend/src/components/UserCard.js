export default function UserCard({ user }) {
  return (
    <div className="card">
      <h3>{user.name}</h3>
      <p>Email: {user.email}</p>
    </div>
  );
}