export default function Dashboard() {
  return (
    <div className="dashboard-main">
      <h2>Bienvenido al Panel</h2>
      <p>Administra cursos, productos, usuarios y suscripciones desde aquí.</p>
    </div>
  );
}