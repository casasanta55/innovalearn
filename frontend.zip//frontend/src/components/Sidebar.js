import Link from "next/link";

export default function Sidebar() {
  return (
    <aside className="sidebar">
      <h2>Panel Admin</h2>
      <ul>
        <li><Link href="/dashboard">Dashboard</Link></li>
        <li><Link href="/courses">Cursos</Link></li>
        <li><Link href="/products">Productos</Link></li>
        <li><Link href="/users">Usuarios</Link></li>
        <li><Link href="/subscriptions">Suscripciones</Link></li>
      </ul>
    </aside>
  );
}