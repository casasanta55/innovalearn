export default function SubscriptionCard({ subscription }) {
  return (
    <div className="card">
      <h3>Tipo: {subscription.type}</h3>
      <p>Estado: {subscription.status}</p>
    </div>
  );
}