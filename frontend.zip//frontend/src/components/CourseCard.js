export default function CourseCard({ course }) {
  return (
    <div className="card">
      <h3>{course.name}</h3>
      <p>{course.description}</p>
    </div>
  );
}