import Link from "next/link";

export default function Navbar() {
  return (
    <nav>
      <h1>InnovaLearn</h1>
      <ul>
        <li><Link href="/">Inicio</Link></li>
        <li><Link href="/courses">Cursos</Link></li>
        <li><Link href="/products">Productos</Link></li>
        <li><Link href="/users">Usuarios</Link></li>
        <li><Link href="/subscriptions">Suscripciones</Link></li>
      </ul>
    </nav>
  );
}