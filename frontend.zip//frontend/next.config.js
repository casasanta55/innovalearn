/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    domains: ["localhost"], // permite cargar imágenes desde el backend
  },
};

module.exports = nextConfig;