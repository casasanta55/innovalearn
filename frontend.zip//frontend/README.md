# InnovaLearn Frontend

Este es el frontend de **InnovaLearn**, construido con **Next.js + React**.

## 🚀 Scripts
- `npm run dev` → inicia el servidor de desarrollo en `http://localhost:3000`
- `npm run build` → compila la aplicación para producción
- `npm start` → inicia la versión compilada

## 📂 Estructura
- `public/` → recursos estáticos (logo, íconos, imágenes)
- `src/components/` → componentes reutilizables
- `src/pages/` → rutas principales
- `src/styles/` → estilos globales y específicos
- `src/hooks/` → hooks personalizados
- `src/context/` → contexto global de autenticación
- `src/utils/` → funciones auxiliares (API)

## 🔗 Conexión
El frontend se comunica con el backend en `http://localhost:5000/api`.