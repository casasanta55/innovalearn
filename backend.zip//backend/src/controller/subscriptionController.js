const Subscription = require("../models/Subscription");

exports.getSubscriptions = async (req, res) => {
  const subs = await Subscription.find().populate("user");
  res.json(subs);
};

exports.addSubscription = async (req, res) => {
  const sub = new Subscription(req.body);
  await sub.save();
  res.status(201).json(sub);
};

exports.deleteSubscription = async (req, res) => {
  await Subscription.findByIdAndDelete(req.params.id);
  res.json({ message: "Suscripción eliminada" });
};