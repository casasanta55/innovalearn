const Order = require("../models/Order");

exports.getOrders = async (req, res) => {
  const orders = await Order.find().populate("product user");
  res.json(orders);
};

exports.addOrder = async (req, res) => {
  const order = new Order(req.body);
  await order.save();
  res.status(201).json(order);
};

exports.deleteOrder = async (req, res) => {
  await Order.findByIdAndDelete(req.params.id);
  res.json({ message: "Orden eliminada" });
};