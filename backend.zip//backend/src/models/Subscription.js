const mongoose = require("mongoose");

const subscriptionSchema = new mongoose.Schema({
  type: { type: String, enum: ["monthly", "annual"], required: true },
  status: { type: String, enum: ["active", "inactive"], default: "active" },
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  startDate: { type: Date, default: Date.now },
  endDate: { type: Date }
}, { timestamps: true });

module.exports = mongoose.model("Subscription", subscriptionSchema);