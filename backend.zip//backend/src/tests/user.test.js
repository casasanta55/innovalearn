const request = require("supertest");
const app = require("../server");
const mongoose = require("mongoose");

describe("User API", () => {
  afterAll(async () => {
    await mongoose.connection.close();
  });

  it("Debe obtener usuarios", async () => {
    const res = await request(app).get("/api/users");
    expect(res.statusCode).toEqual(200);
    expect(Array.isArray(res.body)).toBe(true);
  });
});