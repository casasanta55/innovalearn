const request = require("supertest");
const app = require("../server");
const mongoose = require("mongoose");

describe("Subscription API", () => {
  afterAll(async () => {
    await mongoose.connection.close();
  });

  it("Debe crear una suscripción", async () => {
    const res = await request(app)
      .post("/api/subscriptions")
      .send({ type: "monthly", status: "active" });
    expect(res.statusCode).toEqual(201);
    expect(res.body).toHaveProperty("type", "monthly");
  });

  it("Debe obtener suscripciones", async () => {
    const res = await request(app).get("/api/subscriptions");
    expect(res.statusCode).toEqual(200);
    expect(Array.isArray(res.body)).toBe(true);
  });
});