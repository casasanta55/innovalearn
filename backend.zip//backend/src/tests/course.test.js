const request = require("supertest");
const app = require("../server");
const mongoose = require("mongoose");

describe("Course API", () => {
  afterAll(async () => {
    await mongoose.connection.close();
  });

  it("Debe crear un curso", async () => {
    const res = await request(app)
      .post("/api/courses")
      .send({ name: "Curso Test", description: "Descripción" });
    expect(res.statusCode).toEqual(201);
    expect(res.body).toHaveProperty("name", "Curso Test");
  });

  it("Debe obtener cursos", async () => {
    const res = await request(app).get("/api/courses");
    expect(res.statusCode).toEqual(200);
    expect(Array.isArray(res.body)).toBe(true);
  });
});