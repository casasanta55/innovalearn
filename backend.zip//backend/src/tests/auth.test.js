const request = require("supertest");
const app = require("../server");
const mongoose = require("mongoose");

describe("Auth API", () => {
  afterAll(async () => {
    await mongoose.connection.close();
  });

  it("Debe registrar un usuario", async () => {
    const res = await request(app)
      .post("/api/auth/register")
      .send({ name: "Test", email: "test@test.com", password: "123456" });
    expect(res.statusCode).toEqual(201);
    expect(res.body).toHaveProperty("token");
  });

  it("Debe hacer login", async () => {
    const res = await request(app)
      .post("/api/auth/login")
      .send({ email: "test@test.com", password: "123456" });
    expect(res.statusCode).toEqual(200);
    expect(res.body).toHaveProperty("token");
  });
});