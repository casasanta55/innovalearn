const request = require("supertest");
const app = require("../server");
const mongoose = require("mongoose");

describe("Product API", () => {
  afterAll(async () => {
    await mongoose.connection.close();
  });

  it("Debe crear un producto", async () => {
    const res = await request(app)
      .post("/api/products")
      .send({ name: "Producto Test", price: 50 });
    expect(res.statusCode).toEqual(201);
    expect(res.body).toHaveProperty("name", "Producto Test");
  });

  it("Debe obtener productos", async () => {
    const res = await request(app).get("/api/products");
    expect(res.statusCode).toEqual(200);
    expect(Array.isArray(res.body)).toBe(true);
  });
});