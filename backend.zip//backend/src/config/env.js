require("dotenv").config();

module.exports = {
  port: process.env.PORT || 5000,
  mongoURI: process.env.MONGO_URI,
  jwtSecret: process.env.JWT_SECRET,
  paypalClient: process.env.PAYPAL_CLIENT,
  paypalSecret: process.env.PAYPAL_SECRET,
  transfermovilKey: process.env.TRANSFERMOVIL_KEY,
  hotmartKey: process.env.HOTMART_KEY
};