// Simulación de integración con Hotmart
module.exports = {
  getCourses: async () => {
    return [{ id: 1, name: "Curso IA Básico" }];
  }
};