// Simulación de integración con Transfermóvil
module.exports = {
  processPayment: async (phone, amount) => {
    return { status: "success", phone, amount };
  }
};