const validateFields = (fields) => {
  for (const key in fields) {
    if (!fields[key]) {
      return { valid: false, message: `El campo ${key} es obligatorio` };
    }
  }
  return { valid: true };
};

module.exports = validateFields;