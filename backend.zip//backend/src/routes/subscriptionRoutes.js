const express = require("express");
const { getSubscriptions, addSubscription, deleteSubscription } = require("../controllers/subscriptionController");
const router = express.Router();

router.get("/", getSubscriptions);
router.post("/", addSubscription);
router.delete("/:id", deleteSubscription);

module.exports = router;