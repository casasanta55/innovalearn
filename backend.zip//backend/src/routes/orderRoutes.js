const express = require("express");
const { getOrders, addOrder, deleteOrder } = require("../controllers/orderController");
const router = express.Router();

router.get("/", getOrders);
router.post("/", addOrder);
router.delete("/:id", deleteOrder);

module.exports = router;